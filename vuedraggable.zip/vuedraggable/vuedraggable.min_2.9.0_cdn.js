'use strict';
function _toConsumableArray(t) {
  if (Array.isArray(t)) {
    for (var e = 0, n = Array(t.length); e < t.length; e++) n[e] = t[e];
    return n;
  }
  return Array.from(t);
}
var _extends =
  Object.assign ||
  function (t) {
    for (var e = 1; e < arguments.length; e++) {
      var n = arguments[e];
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (t[i] = n[i]);
    }
    return t;
  };
!(function () {
  function t(t) {
    function e(t) {
      t.parentElement.removeChild(t);
    }
    function n(t, e, n) {
      n < t.children.length ? t.insertBefore(e, t.children[n]) : t.appendChild(e);
    }
    function i(t, e) {
      return t
        .map(function (t) {
          return t.elm;
        })
        .indexOf(e);
    }
    function o(t, e) {
      return t
        ? Array.prototype.map.call(e, function (e) {
            return i(t, e);
          })
        : [];
    }
    function r(t, e) {
      this.$emit(t.toLowerCase(), e);
    }
    function s(t) {
      var e = this;
      return function (n) {
        null !== e.realList && e['onDrag' + t](n), r.call(e, t, n);
      };
    }
    var l = ['Start', 'Add', 'Remove', 'Update', 'End'],
      u = ['Choose', 'Sort', 'Filter', 'Clone'],
      a = ['Move'].concat(l, u).map(function (t) {
        return 'on' + t;
      }),
      d = null,
      c = {
        options: Object,
        list: { type: Array, required: !1, default: null },
        value: { type: Array, required: !1, default: null },
        clone: {
          type: Function,
          default: function (t) {
            return t;
          },
        },
        element: { type: String, default: 'div' },
        move: { type: Function, default: null },
      },
      f = {
        props: c,
        data: function () {
          return { transitionMode: !1 };
        },
        render: function (t) {
          if (this.$slots['default'] && 1 === this.$slots['default'].length) {
            var e = this.$slots['default'][0];
            e.componentOptions && 'transition-group' === e.componentOptions.tag && (this.transitionMode = !0);
          }
          return t(this.element, null, this.$slots['default']);
        },
        mounted: function () {
          var e = this,
            n = {};
          l.forEach(function (t) {
            n['on' + t] = s.call(e, t);
          }),
            u.forEach(function (t) {
              n['on' + t] = r.bind(e, t);
            });
          var i = _extends({}, this.options, n, {
            onMove: function (t) {
              return e.onDragMove(t);
            },
          });
          (this._sortable = new t(this.rootContainer, i)), this.computeIndexes();
        },
        beforeDestroy: function () {
          this._sortable.destroy();
        },
        computed: {
          rootContainer: function () {
            return this.transitionMode ? this.$el.children[0] : this.$el;
          },
          isCloning: function () {
            return !!this.options && !!this.options.group && 'clone' === this.options.group.pull;
          },
          realList: function () {
            return this.list ? this.list : this.value;
          },
        },
        watch: {
          options: function (t) {
            for (var e in t) a.indexOf(e) == -1 && this._sortable.option(e, t[e]);
          },
          realList: function () {
            this.computeIndexes();
          },
        },
        methods: {
          getChildrenNodes: function () {
            var t = this.$slots['default'];
            return this.transitionMode ? t[0].child.$slots['default'] : t;
          },
          computeIndexes: function () {
            var t = this;
            this.$nextTick(function () {
              t.visibleIndexes = o(t.getChildrenNodes(), t.rootContainer.children);
            });
          },
          getUnderlyingVm: function (t) {
            var e = i(this.getChildrenNodes(), t),
              n = this.realList[e];
            return { index: e, element: n };
          },
          getUnderlyingPotencialDraggableComponent: function (t) {
            var e = t.__vue__;
            return e && e.$options && 'transition-group' === e.$options._componentTag ? e.$parent : e;
          },
          emitChanges: function (t) {
            var e = this;
            this.$nextTick(function () {
              e.$emit('change', t);
            });
          },
          alterList: function (t) {
            if (this.list) t(this.list);
            else {
              var e = [].concat(_toConsumableArray(this.value));
              t(e), this.$emit('input', e);
            }
          },
          spliceList: function h() {
            var t = arguments,
              h = function (e) {
                return e.splice.apply(e, t);
              };
            this.alterList(h);
          },
          updatePosition: function m(t, e) {
            var m = function (n) {
              return n.splice(e, 0, n.splice(t, 1)[0]);
            };
            this.alterList(m);
          },
          getRelatedContextFromMoveEvent: function (t) {
            var e = t.to,
              n = t.related,
              i = this.getUnderlyingPotencialDraggableComponent(e);
            if (!i) return { component: i };
            var o = i.realList,
              r = { list: o, component: i };
            if (e !== n && o && i.getUnderlyingVm) {
              var s = i.getUnderlyingVm(n);
              return _extends(s, r);
            }
            return r;
          },
          getVmIndex: function (t) {
            var e = this.visibleIndexes,
              n = e.length;
            return t > n - 1 ? n : e[t];
          },
          onDragStart: function (t) {
            (this.context = this.getUnderlyingVm(t.item)),
              (t.item._underlying_vm_ = this.clone(this.context.element)),
              (d = t.item);
          },
          onDragAdd: function (t) {
            var n = t.item._underlying_vm_;
            if (void 0 !== n) {
              e(t.item);
              var i = this.getVmIndex(t.newIndex);
              this.spliceList(i, 0, n), this.computeIndexes();
              var o = { element: n, newIndex: i };
              this.emitChanges({ added: o });
            }
          },
          onDragRemove: function (t) {
            if ((n(this.rootContainer, t.item, t.oldIndex), this.isCloning)) return void e(t.clone);
            var i = this.context.index;
            this.spliceList(i, 1);
            var o = { element: this.context.element, oldIndex: i };
            this.emitChanges({ removed: o });
          },
          onDragUpdate: function (t) {
            e(t.item), n(t.from, t.item, t.oldIndex);
            var i = this.context.index,
              o = this.getVmIndex(t.newIndex);
            this.updatePosition(i, o);
            var r = { element: this.context.element, oldIndex: i, newIndex: o };
            this.emitChanges({ moved: r });
          },
          computeFutureIndex: function (t, e) {
            if (!t.element) return 0;
            var n = [].concat(_toConsumableArray(e.to.children)),
              i = n.indexOf(e.related),
              o = t.component.getVmIndex(i),
              r = n.indexOf(d) != -1;
            return r ? o : o + 1;
          },
          onDragMove: function (t) {
            var e = this.move;
            if (!e || !this.realList) return !0;
            var n = this.getRelatedContextFromMoveEvent(t),
              i = this.context,
              o = this.computeFutureIndex(n, t);
            return _extends(i, { futureIndex: o }), _extends(t, { relatedContext: n, draggedContext: i }), e(t);
          },
          onDragEnd: function (t) {
            this.computeIndexes(), (d = null);
          },
        },
      };
    return f;
  }
  if (typeof exports == 'object') {
    var e = require('sortablejs');
    module.exports = t(e);
  } else if ('function' == typeof define && define.amd)
    define(['sortablejs'], function (e) {
      return t(e);
    });
  else if (window && window.Vue && window.Sortable) {
    var n = t(window.Sortable);
    Vue.component('draggable', n);
  }
})();
