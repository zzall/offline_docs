export namespace events {
    export { manage };
    export { manageAndEmit };
    export { emit };
}
export function isReadOnly(eventName: any): boolean;
declare const manage: string[];
declare const manageAndEmit: string[];
declare const emit: string[];
export {};
