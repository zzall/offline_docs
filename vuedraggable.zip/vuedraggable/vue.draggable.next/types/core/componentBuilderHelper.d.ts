export function getComponentAttributes({ $attrs, componentData }: {
    $attrs: any;
    componentData?: {};
}): any;
export function createSortableOption({ $attrs, callBackBuilder }: {
    $attrs: any;
    callBackBuilder: any;
}): any;
export function getValidSortableEntries(value: any): any[][];
