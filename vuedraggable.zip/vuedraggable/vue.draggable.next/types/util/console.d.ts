export const console: Console;
