export function camelize(str: any): any;
